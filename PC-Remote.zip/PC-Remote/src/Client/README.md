Client part of the project.
