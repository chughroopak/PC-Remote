Server part of the project.
